package com.example.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.view.MenuItemCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class Receta4 extends AppCompatActivity implements View.OnClickListener {
    private TextView saida;
    private EditText entrada;
    private Button enviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receta4);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        entrada = (EditText) findViewById(R.id.entrada);
        saida = (TextView) findViewById(R.id.saida);
        enviar = (Button) findViewById(R.id.enviar);
        enviar.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.enviar) {
            String end = "https://api.spoonacular.com/recipes/complexSearch" + entrada.getText().toString().trim();
            tarefa t = new tarefa();
            t.execute(end);
        }
    }

    @SuppressLint("StaticFieldLeak")
    class tarefa extends AsyncTask<String, Void, String> {


        @Override
        protected void onPostExecute(String p) {
            super.onPostExecute(p);
            JSONObject j = null;
            try {
                j = new JSONObject(p.toString());
                saida.setText(j.getString("receta"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        protected String doInBackground(String... strings) {
            StringBuffer retorno = new StringBuffer();
            try {
                URL url2 = new URL(strings[0]);
                HttpsURLConnection conexao = (HttpsURLConnection) url2.openConnection();
                InputStream input = conexao.getInputStream();
                InputStreamReader reader = new InputStreamReader(input);
                BufferedReader buffer = new BufferedReader(reader);
                String linha = "";
                if ((linha = buffer.readLine()) != null) {
                    retorno.append(linha);
                }
                System.out.println(retorno.toString());


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return retorno.toString();
        }


    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setOnQueryTextListener(onSearch());


        MenuItem shareitem = menu.findItem(R.id.action_share);
        ShareActionProvider share = (ShareActionProvider) MenuItemCompat.getActionProvider(shareitem);
        share.setShareIntent(configuraIntent());
        return true;

    }

    private Intent configuraIntent() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/*");
        intent.putExtra(Intent.EXTRA_INTENT, "TEXTO COMPARTIR");
        return intent;
    }

    private SearchView.OnQueryTextListener onSearch() {
        return new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        };

    }

    public boolean OnOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            toast("clicou em buscar");

            return true;


        }
        return super.onOptionsItemSelected(item);

    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }

}