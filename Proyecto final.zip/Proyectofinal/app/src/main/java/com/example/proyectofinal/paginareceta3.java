package com.example.proyectofinal;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.view.MenuItemCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

public class paginareceta3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paginareceta3);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        ActionBar.Tab tab1=actionBar.newTab().setText("FRag1");
        tab1.setTabListener(new MyTabListener(this,new Fragment_1()));
        actionBar.addTab(tab1);

        ActionBar.Tab tab2=actionBar.newTab().setText("FRag2");
        tab2.setTabListener(new MyTabListener(this,new Fragment_2()));
        actionBar.addTab(tab2);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item=menu.findItem(R.id.action_search);
        SearchView searchView=(SearchView) item.getActionView();
        searchView.setOnQueryTextListener(onSearch());



        MenuItem shareitem= menu.findItem(R.id.action_share);
        ShareActionProvider share=(ShareActionProvider) MenuItemCompat.getActionProvider(shareitem);
        share.setShareIntent(configuraIntent());
        return true;

    }

    private Intent configuraIntent(){
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("text/*");
        intent.putExtra(Intent.EXTRA_INTENT,"TEXTO COMPARTIR");
        return intent;
    }
    private SearchView.OnQueryTextListener onSearch(){
        return new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getApplicationContext(),s , Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        };

    }

    public boolean OnOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            Toast.makeText(getApplicationContext(),"Menu_Search",Toast.LENGTH_SHORT).show();
            return true;


        }

        else if (id == R.id.action_settings) {
            Intent intent=new Intent(getApplicationContext(),paginareceta2.class);
            startActivity(intent);
            // Toast.makeText(getApplicationContext(),"Menu_Refresh",Toast.LENGTH_SHORT).show();

            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    private void toast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }
}