package com.example.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.view.MenuItemCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn1, btn2, btn3,btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4=findViewById(R.id.btn4);
        btn4.setOnClickListener(this);
    }





    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
      MenuItem item=menu.findItem(R.id.action_search);
      SearchView searchView=(SearchView) item.getActionView();
         searchView.setOnQueryTextListener(onSearch());



         MenuItem shareitem= menu.findItem(R.id.action_share);
        ShareActionProvider share=(ShareActionProvider) MenuItemCompat.getActionProvider(shareitem);
          share.setShareIntent(configuraIntent());
        return true;

    }

private Intent configuraIntent(){
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("text/*");
        intent.putExtra(Intent.EXTRA_INTENT,"TEXTO COMPARTIR");
        return intent;
}
    private SearchView.OnQueryTextListener onSearch(){
        return new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getApplicationContext(),s , Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        };

    }

    public boolean OnOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
Toast.makeText(getApplicationContext(),"Menu_Search",Toast.LENGTH_SHORT).show();
            return true;


        }

    else if (id == R.id.action_settings) {
        Intent intent=new Intent(getApplicationContext(),paginareceta2.class);
        startActivity(intent);
            // Toast.makeText(getApplicationContext(),"Menu_Refresh",Toast.LENGTH_SHORT).show();

        return true;
    }
        return super.onOptionsItemSelected(item);

    }

    private void toast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn1) {
            Intent intent = new Intent(getApplicationContext(), paginareceta1.class);
            startActivity(intent);
        } else if (view.getId() == R.id.btn2) {
            Intent intent = new Intent(getApplicationContext(), paginareceta2.class);
            startActivity(intent);

        } else if (view.getId() == R.id.btn3) {
            Intent intent = new Intent(getApplicationContext(), paginareceta3.class);
            startActivity(intent);
       } else if (view.getId() == R.id.btn4) {
        Intent intent = new Intent(getApplicationContext(), Receta4.class);
           startActivity(intent);
        }

    }
    }

