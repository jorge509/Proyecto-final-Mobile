package com.example.proyectofinal;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
public class recetadb  extends SQLiteOpenHelper {
    private static final String TAG="sql";
    private static final String NOME_BANCO="receta.sqLite";
    private static final int VERSAO=1;
    public recetadb(Context context) {
        super(context, "receta.sqlite", null, 1);
    }
    public long save(receta r) {
        int id = r.getId();
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("ingredientes", r.getIngredientes());
            values.put("tiempo", r.getTiempo());
            if (id != 0) {
//actualizar
                String _id = String.valueOf(r.getId());
                String[] args = new String[]{_id};
                int count = db.update("receta", values, "_id=?", args);
                return count;
            } else {
                //insertart
                id = (int) db.insert("receta", null, values);
                return id;
            }
        } finally {
            db.close();
        }
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d(TAG,"criando a tabela receta");
        sqLiteDatabase.execSQL("create table if not exists receta(id integer primary key autoincrement,ingredientes text, tiempo text)");
        Log.d(TAG, "tabela criada");
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }
    @SuppressLint("Range")
    public List<receta> buscar() {
        SQLiteDatabase db = getWritableDatabase();
        try {
            Cursor c = db.rawQuery("select * from receta ", null);
            return toList(c);
        } finally {
            db.close();
        }
    }

    @SuppressLint("Range")
    private List<receta>toList(Cursor c) {
        List<receta> recet = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                receta r = new receta();
                r.setId(c.getInt(c.getColumnIndex("id")));
                r.setIngredientes(c.getString(c.getColumnIndex("ingredientes")));
                r.setTiempo(c.getString(c.getColumnIndex("tiempo")));
                recet.add(r);

            } while (c.moveToNext());
        }
        return recet;

    }
}