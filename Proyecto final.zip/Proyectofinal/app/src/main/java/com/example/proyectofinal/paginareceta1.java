package com.example.proyectofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.view.MenuItemCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.List;

public class paginareceta1 extends AppCompatActivity implements  View.OnClickListener{
private TextView rc1;
private EditText time;
private ImageView imv;
private EditText recet;
private TextView tv8;
private TextView tiempo;
    private recetadb db;

  private Button btng,btnb;
private TextView ingredientes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paginareceta1);
        recet=(EditText)findViewById(R.id.recet);
        time=(EditText) findViewById(R.id.time);
        btng=(Button) findViewById(R.id.btng);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
btnb=(Button)findViewById(R.id.btnb);
        btng.setOnClickListener(this);
        btnb.setOnClickListener(this);
         db=new recetadb(this);
    }



    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item=menu.findItem(R.id.action_search);
        SearchView searchView=(SearchView) item.getActionView();
        searchView.setOnQueryTextListener(onSearch());

        MenuItem shareitem= menu.findItem(R.id.action_share);
        ShareActionProvider share=(ShareActionProvider) MenuItemCompat.getActionProvider(shareitem);
        share.setShareIntent(configuraIntent());
        return true;
    }

    private Intent configuraIntent() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/*");
        intent.putExtra(Intent.EXTRA_INTENT, "TEXTO COMPARTIR");
        return intent;
    }
    private SearchView.OnQueryTextListener onSearch(){
        return new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getApplicationContext(),s , Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        };

    }

    public boolean OnOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            Toast.makeText(getApplicationContext(),"Menu_Search",Toast.LENGTH_SHORT).show();

            return true;




        }
        return super.onOptionsItemSelected(item);

    }

    private void toast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }





    public void onClick(@NonNull View view) {
        if(view.getId()==R.id.btng){
            receta r=new receta();
       r.setIngredientes(recet.getText().toString().trim());
            r.setTiempo(time.getText().toString().trim());
            db.save(r);

    }
      else if(view.getId()==R.id.btnb){
        List<receta> recet=db.buscar();
        for (int i=0;i<recet.size();i++){
            System.out.println(recet.get(i).getId()+"");
            System.out.println(recet.get(i).getIngredientes()+"");
            System.out.println(recet.get(i).getTiempo()+"");
        }
        Intent i=new  Intent(this,receta_cadastrada.class);
        i.putExtra("objList",(Serializable) recet);
        startActivity(i);
    }





}






}





