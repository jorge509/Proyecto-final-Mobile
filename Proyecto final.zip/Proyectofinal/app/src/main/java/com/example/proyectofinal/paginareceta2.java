package com.example.proyectofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.Serializable;
import java.util.List;

public class paginareceta2 extends AppCompatActivity implements  View.OnClickListener{

    private TextView rc1;
    private EditText time;
    private ImageView imv;
    private TextView tv8;
    private TextView tiempo;
    private recetadb db;
    private EditText recet;
    private Button btng,btnb;
    private TextView ingredientes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paginareceta2);
        recet=(EditText)findViewById(R.id.recet);
        time=(EditText) findViewById(R.id.time);
        btng=(Button) findViewById(R.id.btng);
        btnb=(Button)findViewById(R.id.btnb);
        btng.setOnClickListener(this);
        btnb.setOnClickListener(this);
        db=new recetadb(this);

    }

    public void onClick(View view) {
        if(view.getId()==R.id.btng){
            receta r=new receta();
            r.setIngredientes(ingredientes.getText().toString().trim());
            r.setTiempo(tiempo.getText().toString().trim());
            db.save(r);


        }
        else if(view.getId()==R.id.btnb){
            List<receta> recet=db.buscar();
            for (int i=0;i<recet.size();i++){
                System.out.println(recet.get(i).getId()+"");
                System.out.println(recet.get(i).getIngredientes()+"");
                System.out.println(recet.get(i).getTiempo()+"");
            }
            Intent i=new  Intent(this,receta_cadastrada.class);
            i.putExtra("objList",(Serializable) recet);
            startActivity(i);
        }
    }
}





