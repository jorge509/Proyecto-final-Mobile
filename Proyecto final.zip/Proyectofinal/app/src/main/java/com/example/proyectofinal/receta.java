package com.example.proyectofinal;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;


public class receta extends AppCompatActivity implements Serializable, View.OnClickListener {
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int id;
private String ingredientes;
private String tiempo;

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public void onClick(View view) {

    }
}




